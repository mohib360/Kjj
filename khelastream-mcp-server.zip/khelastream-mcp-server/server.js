import express from "express";
import { randomBytes, timingSafeEqual } from "node:crypto";
import { initializeApp, cert, getApps } from "firebase-admin/app";
import { getDatabase } from "firebase-admin/database";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";

const required = ["MCP_API_TOKEN", "FIREBASE_DATABASE_URL", "FIREBASE_SERVICE_ACCOUNT_JSON"];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Missing required environment variable: ${key}`);
    process.exit(1);
  }
}

const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
if (!getApps().length) {
  initializeApp({
    credential: cert(serviceAccount),
    databaseURL: process.env.FIREBASE_DATABASE_URL
  });
}
const db = getDatabase();

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));

function safeTokenEqual(provided, expected) {
  const a = Buffer.from(provided || "");
  const b = Buffer.from(expected || "");
  return a.length === b.length && timingSafeEqual(a, b);
}

function authenticate(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!safeTokenEqual(token, process.env.MCP_API_TOKEN)) {
    return res.status(401).json({ error: "Unauthorized. Provide a valid Bearer token." });
  }
  next();
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "KhelaStream MCP", version: "1.0.0" }));

function makeServer() {
  const server = new McpServer({
    name: "khelastream-mcp",
    version: "1.0.0"
  });

  server.tool(
    "list_matches",
    "List KhelaStream matches. Supports optional sport/status filters and a maximum result count.",
    {
      sport: z.string().optional(),
      status: z.enum(["live", "upcoming", "finished", "all"]).optional(),
      limit: z.number().int().min(1).max(100).optional()
    },
    async ({ sport, status = "all", limit = 50 }) => {
      const snap = await db.ref("matches").get();
      const raw = snap.val() || {};
      let rows = Object.entries(raw).map(([id, value]) => ({ id, ...(value || {}) }));
      if (sport) rows = rows.filter(x => String(x.sport || "").toLowerCase() === sport.toLowerCase());
      if (status !== "all") rows = rows.filter(x => String(x.status || "upcoming").toLowerCase() === status);
      rows = rows.slice(0, limit);
      return { content: [{ type: "text", text: JSON.stringify(rows, null, 2) }] };
    }
  );

  server.tool(
    "get_match",
    "Get one KhelaStream match by Firebase record ID.",
    { match_id: z.string().min(1) },
    async ({ match_id }) => {
      const snap = await db.ref(`matches/${match_id}`).get();
      if (!snap.exists()) return { content: [{ type: "text", text: "Match not found." }], isError: true };
      return { content: [{ type: "text", text: JSON.stringify({ id: match_id, ...snap.val() }, null, 2) }] };
    }
  );

  server.tool(
    "find_match_by_name",
    "Find matches by team name or match title. Does not search for or retrieve stream URLs.",
    { query: z.string().min(2), limit: z.number().int().min(1).max(50).optional() },
    async ({ query, limit = 20 }) => {
      const snap = await db.ref("matches").get();
      const q = query.toLowerCase();
      const rows = Object.entries(snap.val() || {})
        .map(([id, value]) => ({ id, ...(value || {}) }))
        .filter(x => [x.team1, x.team2, x.title].some(v => String(v || "").toLowerCase().includes(q)))
        .slice(0, limit);
      return { content: [{ type: "text", text: JSON.stringify(rows, null, 2) }] };
    }
  );

  server.tool(
    "add_match",
    "Add a match record to KhelaStream. This tool does not add or discover stream URLs.",
    {
      sport: z.string().default("football"),
      status: z.enum(["live", "upcoming", "finished"]).default("upcoming"),
      team1: z.string().min(1),
      team2: z.string().min(1),
      title: z.string().optional(),
      team1Logo: z.string().url().optional(),
      team2Logo: z.string().url().optional(),
      isoTime: z.string().optional(),
      score1: z.string().optional(),
      score2: z.string().optional()
    },
    async (input) => {
      const record = Object.fromEntries(Object.entries(input).filter(([, v]) => v !== undefined));
      const ref = db.ref("matches").push();
      await ref.set(record);
      return { content: [{ type: "text", text: JSON.stringify({ ok: true, id: ref.key, match: record }, null, 2) }] };
    }
  );

  server.tool(
    "update_match",
    "Update selected fields of an existing KhelaStream match by record ID. Stream URLs are not editable with this tool.",
    {
      match_id: z.string().min(1),
      sport: z.string().optional(),
      status: z.enum(["live", "upcoming", "finished"]).optional(),
      team1: z.string().optional(),
      team2: z.string().optional(),
      title: z.string().optional(),
      team1Logo: z.string().url().optional(),
      team2Logo: z.string().url().optional(),
      isoTime: z.string().optional(),
      score1: z.string().optional(),
      score2: z.string().optional()
    },
    async ({ match_id, ...fields }) => {
      const patch = Object.fromEntries(Object.entries(fields).filter(([, v]) => v !== undefined));
      if (!Object.keys(patch).length) return { content: [{ type: "text", text: "No fields supplied." }], isError: true };
      const ref = db.ref(`matches/${match_id}`);
      if (!(await ref.get()).exists()) return { content: [{ type: "text", text: "Match not found." }], isError: true };
      await ref.update(patch);
      return { content: [{ type: "text", text: JSON.stringify({ ok: true, id: match_id, updated: patch }, null, 2) }] };
    }
  );

  server.tool(
    "delete_match",
    "Delete a match only when the caller supplies the exact confirmation phrase DELETE MATCH. This does not alter streams.",
    {
      match_id: z.string().min(1),
      confirm: z.literal("DELETE MATCH")
    },
    async ({ match_id }) => {
      const ref = db.ref(`matches/${match_id}`);
      if (!(await ref.get()).exists()) return { content: [{ type: "text", text: "Match not found." }], isError: true };
      await ref.remove();
      return { content: [{ type: "text", text: `Deleted match ${match_id}.` }] };
    }
  );

  server.tool(
    "list_stream_status",
    "Show whether each match has a configured stream server, without returning any stream URL. AI must not discover or generate M3U8 links.",
    { limit: z.number().int().min(1).max(100).optional() },
    async ({ limit = 50 }) => {
      const [mSnap, sSnap] = await Promise.all([db.ref("matches").get(), db.ref("streams").get()]);
      const matches = mSnap.val() || {};
      const streams = sSnap.val() || {};
      const rows = Object.entries(matches).slice(0, limit).map(([id, match]) => {
        const s = streams[id] || {};
        return {
          id,
          match: `${match?.team1 || "?"} vs ${match?.team2 || "?"}`,
          hasServer1: Boolean(s.srv1),
          hasServer2: Boolean(s.srv2),
          hasServer3: Boolean(s.srv3)
        };
      });
      return { content: [{ type: "text", text: JSON.stringify(rows, null, 2) }] };
    }
  );

  return server;
}

app.all("/mcp", authenticate, async (req, res) => {
  const mcpServer = makeServer();
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined,
    enableJsonResponse: true
  });
  res.on("close", () => {
    transport.close().catch(() => {});
    mcpServer.close().catch(() => {});
  });
  try {
    await mcpServer.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (error) {
    console.error("MCP request failed:", error);
    if (!res.headersSent) res.status(500).json({ error: "MCP request failed" });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => {
  console.log(`KhelaStream MCP listening on port ${port}`);
});
